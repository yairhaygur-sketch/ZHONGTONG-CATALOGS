import assert from "node:assert/strict";
import fs from "node:fs/promises";
import test from "node:test";

const developmentPreviewMeta =
  /<meta(?=[^>]*\bname=["']codex-preview["'])(?=[^>]*\bcontent=["']development["'])[^>]*>/i;

test("includes diagram positions for every LCK6750EVG catalog occurrence", async () => {
  const data = JSON.parse(
    await fs.readFile(
      new URL("../public/parts-data.json", import.meta.url),
      "utf8",
    ),
  );
  const targetCatalog = "Part catalog for LCK6750EVG mini bus_2026_1unit";
  const occurrences = data.parts.flatMap((part) =>
    part.occurrences.filter((occurrence) => occurrence.catalog === targetCatalog),
  );

  assert.equal(occurrences.length, 1200);
  assert.ok(occurrences.every((occurrence) => occurrence.position));
  assert.equal(
    occurrences.find(
      (occurrence) =>
        occurrence.assemblyCode === "LCK6750EVG-BC-05" &&
        occurrence.partNumber === "5403-01-38329",
    )?.position,
    "5",
  );
});

test("renders development preview metadata", async () => {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);

  const response = await worker.fetch(
    new Request("http://localhost/", {
      headers: { accept: "text/html" },
    }),
    {
      ASSETS: {
        fetch: async () => new Response("Not found", { status: 404 }),
      },
    },
    {
      waitUntil() {},
      passThroughOnException() {},
    },
  );

  assert.equal(response.status, 200);
  assert.match(
    response.headers.get("content-type") ?? "",
    /^text\/html\b/i,
  );
  assert.match(await response.text(), developmentPreviewMeta);
});
