# Zhongtong Parts Search — lightweight source package

This package contains the real application source from the live version 44 of the Zhongtong parts catalog.

To keep the package small enough for Claude, the full production catalog and thousands of diagrams were replaced with a representative sample containing one catalog, 12 assemblies, their parts, VINs, and matching diagrams. The application logic, routes, styling, search behavior, catalog browser, part cards, and data-import scripts are unchanged.

## Suggested prompt for Claude

Unzip this project and inspect it as an existing application. Explain its architecture, then run it and recreate or improve the tool while preserving its current behavior. The file `public/parts-data.json` contains sample data only; the production project uses the same schema with a much larger dataset. Do not remove Hebrew RTL or English LTR support.

## Main files

- `app/page.tsx` — main catalog application and interactions
- `app/globals.css` — complete visual design and responsive behavior
- `app/layout.tsx` — application shell and metadata
- `public/parts-data.json` — lightweight catalog sample
- `scripts/import_catalog_update.py` — production catalog import process

## Run locally

```bash
npm ci
npm run dev
```

The large `node_modules` directory and Git history are intentionally not included. Run `npm ci` to recreate dependencies.

The hosting manifest is intentionally detached from the live production Site, so experimenting with this package cannot overwrite the original project. Photo uploads require a new R2 storage binding; the catalog and search features run with the included sample data.
