import { getChatGPTUser } from "../../chatgpt-auth";

export const runtime = "edge";

// Keep the multipart request below the hosted request-body limit. The client
// resizes phone photos before posting them, and the server enforces the limit.
const MAX_FILE_SIZE = 1_400_000;
const ALLOWED_TYPES = new Set(["image/jpeg", "image/png", "image/webp"]);

type PhotoStatus = "verified" | "pending";
type PhotoSource = "warehouse" | "manufacturer" | "workshop" | "other";

type PhotoMetadata = {
  partNumber: string;
  fileName: string;
  uploadedAt: string;
  source: PhotoSource;
  vin: string;
  status: PhotoStatus;
  uploadedBy: string;
  updatedAt?: string;
  updatedBy?: string;
};

const PHOTO_ADMIN_EMAILS = new Set(["yairhaygur@gmail.com"]);

const bucket = () => {
  const value = globalThis.__ZT_SITE_ENV__?.BUCKET;
  if (!value) throw new Error("Photo storage is unavailable");
  return value;
};

const json = (body: unknown, status = 200) =>
  Response.json(body, {
    status,
    headers: { "Cache-Control": "no-store" },
  });

const cleanPartNumber = (value: FormDataEntryValue | string | null) => {
  const normalized = String(value ?? "").trim().toUpperCase();
  return /^[A-Z0-9._/-]{2,80}$/.test(normalized) ? normalized : "";
};

const extensionFor = (file: File) => {
  if (file.type === "image/png") return "png";
  if (file.type === "image/webp") return "webp";
  return "jpg";
};

const isSameOriginUpload = (request: Request) => {
  const requestUrl = new URL(request.url);
  const origin = request.headers.get("origin");
  const fetchSite = request.headers.get("sec-fetch-site");

  if (requestUrl.hostname === "terminal.local") return true;
  if (!origin || origin !== requestUrl.origin) return false;
  return !fetchSite || fetchSite === "same-origin" || fetchSite === "none";
};

const photoResponse = (key: string, metadata: Partial<PhotoMetadata>, contentType = "") => ({
  key,
  url: `/api/photos?key=${encodeURIComponent(key)}&v=${encodeURIComponent(metadata.updatedAt || metadata.uploadedAt || "")}`,
  fileName: metadata.fileName || "photo",
  contentType,
  uploadedAt: metadata.uploadedAt || "",
  source: metadata.source || "other",
  vin: metadata.vin || "",
  status: metadata.status === "verified" ? "verified" : "pending",
});

const cleanSource = (value: unknown): PhotoSource =>
  ["warehouse", "manufacturer", "workshop", "other"].includes(String(value))
    ? String(value) as PhotoSource
    : "other";

const cleanStatus = (value: unknown): PhotoStatus =>
  String(value) === "verified" ? "verified" : "pending";

const cleanVin = (value: unknown) =>
  String(value ?? "")
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, "")
    .slice(0, 17);

const isKeyForPart = (key: string, partNumber: string) => {
  const prefix = `parts/${encodeURIComponent(partNumber)}/`;
  return key.startsWith(prefix) && !key.slice(prefix.length).includes("/");
};

const photoManager = async () => {
  const user = await getChatGPTUser();
  return {
    user,
    canManage: Boolean(user && PHOTO_ADMIN_EMAILS.has(user.email.toLowerCase())),
  };
};

const requirePhotoManager = async () => {
  const access = await photoManager();
  if (!access.user) {
    return { response: json({ error: "Sign in is required", code: "AUTH_REQUIRED" }, 401), user: null };
  }
  if (!access.canManage) {
    return { response: json({ error: "This account cannot manage photos", code: "NOT_AUTHORIZED" }, 403), user: null };
  }
  return { response: null, user: access.user };
};

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const key = url.searchParams.get("key");

    if (key) {
      if (!key.startsWith("parts/")) return json({ error: "Invalid photo key" }, 400);
      const object = await bucket().get(key);
      if (!object) return json({ error: "Photo not found" }, 404);

      const headers = new Headers();
      object.writeHttpMetadata(headers);
      headers.set("Cache-Control", "public, max-age=3600");
      headers.set("Content-Disposition", "inline");
      headers.set("ETag", object.httpEtag);
      return new Response(object.body, { headers });
    }

    if (url.searchParams.get("scope") === "parts") {
      const objects: Awaited<ReturnType<ReturnType<typeof bucket>["list"]>>["objects"] = [];
      let cursor: string | undefined;

      do {
        const result = await bucket().list({
          prefix: "parts/",
          include: ["customMetadata", "httpMetadata"],
          limit: 1000,
          cursor,
        });
        objects.push(...result.objects);
        cursor = result.truncated ? result.cursor : undefined;
      } while (cursor && objects.length < 5000);

      const byPart = new Map<string, {
        partNumber: string;
        photoCount: number;
        verifiedCount: number;
        pendingCount: number;
        latestPhoto: ReturnType<typeof photoResponse>;
      }>();

      objects.forEach((object) => {
        const metadata = object.customMetadata as Partial<PhotoMetadata>;
        const keyPart = object.key.split("/")[1] || "";
        let decodedKeyPart = "";
        try {
          decodedKeyPart = decodeURIComponent(keyPart);
        } catch {
          decodedKeyPart = keyPart;
        }
        const partNumber = cleanPartNumber(metadata.partNumber || decodedKeyPart);
        if (!partNumber) return;

        const photo = {
          ...photoResponse(
            object.key,
            metadata,
            object.httpMetadata?.contentType || "",
          ),
          uploadedAt: metadata.uploadedAt || object.uploaded.toISOString(),
        };
        const current = byPart.get(partNumber);
        const verified = photo.status === "verified" ? 1 : 0;
        const pending = photo.status === "pending" ? 1 : 0;

        if (!current) {
          byPart.set(partNumber, {
            partNumber,
            photoCount: 1,
            verifiedCount: verified,
            pendingCount: pending,
            latestPhoto: photo,
          });
          return;
        }

        current.photoCount += 1;
        current.verifiedCount += verified;
        current.pendingCount += pending;
        if (photo.uploadedAt.localeCompare(current.latestPhoto.uploadedAt) > 0) {
          current.latestPhoto = photo;
        }
      });

      const parts = [...byPart.values()].sort((a, b) =>
        b.latestPhoto.uploadedAt.localeCompare(a.latestPhoto.uploadedAt)
        || a.partNumber.localeCompare(b.partNumber)
      );
      return json({ parts, truncated: Boolean(cursor) });
    }

    const partNumber = cleanPartNumber(url.searchParams.get("partNumber"));
    if (!partNumber) return json({ error: "A valid part number is required" }, 400);

    const prefix = `parts/${encodeURIComponent(partNumber)}/`;
    const result = await bucket().list({
      prefix,
      include: ["customMetadata", "httpMetadata"],
      limit: 100,
    });

    const photos = result.objects
      .map((object) => ({
        ...photoResponse(
          object.key,
          object.customMetadata as Partial<PhotoMetadata>,
          object.httpMetadata?.contentType || "",
        ),
        uploadedAt: object.customMetadata?.uploadedAt || object.uploaded.toISOString(),
      }))
      .sort((a, b) => b.uploadedAt.localeCompare(a.uploadedAt));

    const access = await photoManager();
    return json({
      photos,
      canManage: access.canManage,
      signedIn: Boolean(access.user),
    });
  } catch (error) {
    console.error("Photo retrieval failed", error);
    return json({ error: "Photo storage is unavailable" }, 503);
  }
}

export async function POST(request: Request) {
  try {
    if (!isSameOriginUpload(request)) {
      return json({ error: "Photo uploads must come from this site", code: "INVALID_ORIGIN" }, 403);
    }

    const user = await getChatGPTUser();
    const form = await request.formData();
    const file = form.get("file");
    const partNumber = cleanPartNumber(form.get("partNumber"));
    const source = cleanSource(form.get("source"));
    const status: PhotoStatus = "pending";
    const vin = cleanVin(form.get("vin"));

    if (!partNumber) return json({ error: "A valid part number is required" }, 400);
    if (!(file instanceof File) || file.size === 0) return json({ error: "An image is required" }, 400);
    if (!ALLOWED_TYPES.has(file.type)) return json({ error: "Use a JPEG, PNG, or WebP image" }, 415);
    if (file.size > MAX_FILE_SIZE) return json({ error: "The prepared image is too large" }, 413);

    const uploadedAt = new Date().toISOString();
    const key = `parts/${encodeURIComponent(partNumber)}/${Date.now()}-${crypto.randomUUID()}.${extensionFor(file)}`;
    const metadata: PhotoMetadata = {
      partNumber,
      fileName: file.name.slice(0, 180),
      uploadedAt,
      source,
      vin,
      status,
      uploadedBy: user?.email || "public-site",
    };

    await bucket().put(key, file.stream(), {
      httpMetadata: { contentType: file.type },
      customMetadata: metadata,
    });

    return json({
      photo: {
        ...photoResponse(key, metadata, file.type),
      },
    }, 201);
  } catch (error) {
    console.error("Photo upload failed", error);
    return json({ error: "The image could not be saved" }, 500);
  }
}

export async function PATCH(request: Request) {
  try {
    if (!isSameOriginUpload(request)) {
      return json({ error: "Photo changes must come from this site", code: "INVALID_ORIGIN" }, 403);
    }

    const manager = await requirePhotoManager();
    if (manager.response) return manager.response;

    const body = await request.json() as Record<string, unknown>;
    const key = String(body.key ?? "");
    const partNumber = cleanPartNumber(String(body.partNumber ?? ""));
    if (!partNumber || !isKeyForPart(key, partNumber)) {
      return json({ error: "Invalid photo reference" }, 400);
    }

    const existing = await bucket().get(key);
    if (!existing) return json({ error: "Photo not found" }, 404);

    const previous = existing.customMetadata as Partial<PhotoMetadata>;
    const updatedAt = new Date().toISOString();
    const metadata: PhotoMetadata = {
      partNumber,
      fileName: previous.fileName || "photo",
      uploadedAt: previous.uploadedAt || updatedAt,
      source: cleanSource(body.source),
      vin: cleanVin(body.vin),
      status: cleanStatus(body.status),
      uploadedBy: previous.uploadedBy || "unknown",
      updatedAt,
      updatedBy: manager.user!.email,
    };
    const bytes = await existing.arrayBuffer();
    const contentType = existing.httpMetadata?.contentType || "image/jpeg";

    await bucket().put(key, bytes, {
      httpMetadata: { ...existing.httpMetadata, contentType },
      customMetadata: metadata,
    });

    return json({ photo: photoResponse(key, metadata, contentType) });
  } catch (error) {
    console.error("Photo update failed", error);
    return json({ error: "The photo details could not be updated" }, 500);
  }
}

export async function PUT(request: Request) {
  try {
    if (!isSameOriginUpload(request)) {
      return json({ error: "Photo changes must come from this site", code: "INVALID_ORIGIN" }, 403);
    }

    const manager = await requirePhotoManager();
    if (manager.response) return manager.response;

    const form = await request.formData();
    const file = form.get("file");
    const key = String(form.get("key") ?? "");
    const partNumber = cleanPartNumber(form.get("partNumber"));
    if (!partNumber || !isKeyForPart(key, partNumber)) {
      return json({ error: "Invalid photo reference" }, 400);
    }
    if (!(file instanceof File) || file.size === 0) return json({ error: "An image is required" }, 400);
    if (!ALLOWED_TYPES.has(file.type)) return json({ error: "Use a JPEG, PNG, or WebP image" }, 415);
    if (file.size > MAX_FILE_SIZE) return json({ error: "The prepared image is too large" }, 413);

    const existing = await bucket().head(key);
    if (!existing) return json({ error: "Photo not found" }, 404);

    const previous = existing.customMetadata as Partial<PhotoMetadata>;
    const updatedAt = new Date().toISOString();
    const metadata: PhotoMetadata = {
      partNumber,
      fileName: file.name.slice(0, 180),
      uploadedAt: previous.uploadedAt || updatedAt,
      source: cleanSource(form.get("source")),
      vin: cleanVin(form.get("vin")),
      status: cleanStatus(form.get("status")),
      uploadedBy: previous.uploadedBy || "unknown",
      updatedAt,
      updatedBy: manager.user!.email,
    };

    await bucket().put(key, file.stream(), {
      httpMetadata: { contentType: file.type },
      customMetadata: metadata,
    });

    return json({ photo: photoResponse(key, metadata, file.type) });
  } catch (error) {
    console.error("Photo replacement failed", error);
    return json({ error: "The photo could not be replaced" }, 500);
  }
}

export async function DELETE(request: Request) {
  try {
    if (!isSameOriginUpload(request)) {
      return json({ error: "Photo changes must come from this site", code: "INVALID_ORIGIN" }, 403);
    }

    const manager = await requirePhotoManager();
    if (manager.response) return manager.response;

    const url = new URL(request.url);
    const key = url.searchParams.get("key") || "";
    const partNumber = cleanPartNumber(url.searchParams.get("partNumber"));
    if (!partNumber || !isKeyForPart(key, partNumber)) {
      return json({ error: "Invalid photo reference" }, 400);
    }

    const existing = await bucket().head(key);
    if (!existing) return json({ error: "Photo not found" }, 404);
    await bucket().delete(key);
    return json({ deleted: true });
  } catch (error) {
    console.error("Photo deletion failed", error);
    return json({ error: "The photo could not be deleted" }, 500);
  }
}
