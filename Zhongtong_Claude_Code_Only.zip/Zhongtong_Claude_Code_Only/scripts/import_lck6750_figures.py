from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from zipfile import ZipFile

import openpyxl
from lxml import etree
from PIL import Image


SOURCE = Path("/workspace/scratch/1bae3be00283/upload/Part catalog for LCK6750EVG mini bus_2026_1unit.xlsx")
ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "public/parts-data.json"
FIGURES_DIR = ROOT / "public/figures"
CATALOG = "Part catalog for LCK6750EVG mini bus_2026_1unit"


def drawing_anchors(archive: ZipFile) -> list[tuple[int, str]]:
    drawing = etree.fromstring(archive.read("xl/drawings/drawing1.xml"))
    relationships = etree.fromstring(archive.read("xl/drawings/_rels/drawing1.xml.rels"))
    rel_targets = {node.get("Id"): node.get("Target") for node in relationships}
    ns = {
        "xdr": "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing",
        "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
        "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    }
    anchors = []
    for node in drawing:
        origin = node.find("xdr:from", ns)
        blip = node.find(".//a:blip", ns)
        if origin is None or blip is None:
            continue
        row = int(origin.find("xdr:row", ns).text) + 1
        rel_id = blip.get(f"{{{ns['r']}}}embed")
        target = rel_targets[rel_id].replace("../", "xl/")
        anchors.append((row, target))
    return sorted(anchors)


def next_group_code(sheet, start_row: int, end_row: int) -> str:
    for row in range(start_row, end_row + 1):
        value = sheet.cell(row, 1).value
        if not isinstance(value, str):
            continue
        match = re.match(r"\s*(LCK6750EVG-[A-Z]{2}-\d{2})\b", value)
        if match:
            return match.group(1)
    raise ValueError(f"No group heading found between rows {start_row} and {end_row}")


def main() -> None:
    workbook = openpyxl.load_workbook(SOURCE, read_only=True, data_only=True)
    sheet = workbook.active
    data = json.loads(DATA_PATH.read_text(encoding="utf-8"))
    target_groups = {
        group["code"]: group
        for group in data["groups"].values()
        if group["catalog"] == CATALOG
    }

    FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    linked = {}
    with ZipFile(SOURCE) as archive:
        anchors = drawing_anchors(archive)
        for index, (anchor_row, media_path) in enumerate(anchors):
            next_anchor = anchors[index + 1][0] if index + 1 < len(anchors) else sheet.max_row + 1
            code = next_group_code(sheet, anchor_row, next_anchor - 1)
            if code not in target_groups:
                raise KeyError(f"Group {code} is not present in parts-data.json")

            image_bytes = archive.read(media_path)
            digest = hashlib.sha256((CATALOG + code).encode("utf-8") + image_bytes).hexdigest()[:16]
            output = FIGURES_DIR / f"{digest}.webp"
            if not output.exists():
                from io import BytesIO

                with Image.open(BytesIO(image_bytes)) as image:
                    image.thumbnail((1800, 1800), Image.Resampling.LANCZOS)
                    image.convert("RGB").save(output, "WEBP", quality=88, method=6)
            target_groups[code]["figure"] = f"/figures/{output.name}"
            linked[code] = target_groups[code]["figure"]

    if len(linked) != 90:
        raise RuntimeError(f"Expected 90 linked figures, got {len(linked)}")
    missing = sorted(set(target_groups) - set(linked))
    if missing:
        raise RuntimeError(f"LCK6750 groups without figures: {missing}")

    data["figureCount"] = sum(1 for group in data["groups"].values() if group.get("figure"))
    DATA_PATH.write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    print(json.dumps({"linked": len(linked), "figureCount": data["figureCount"]}))


if __name__ == "__main__":
    main()
